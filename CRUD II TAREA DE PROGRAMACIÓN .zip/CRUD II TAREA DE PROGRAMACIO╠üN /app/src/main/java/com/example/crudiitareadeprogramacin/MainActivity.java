package com.example.crudiitareadeprogramacin;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.CharArrayWriter;

public class MainActivity extends AppCompatActivity {
    EditText NOMBRE_COMPLETO,DIRECCIÓN,TELEFONO;
    Button insert,LISTA_DE_PRODUCTOS, update, delete;
    DatabaseHandler DB;
    String action="new";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        NOMBRE_COMPLETO=findViewById(R.id.NOMBRE_COMPLETO);
        DIRECCIÓN=findViewById(R.id.DIRECCIÓN);
        TELEFONO=findViewById(R.id.TELEFONO);
        insert=findViewById(R.id.btnInsert);
        update= findViewById(R.id.btnUpdate);
        delete=findViewById(R.id.btnDelete);
        LISTA_DE_PRODUCTOS=findViewById(R.id.btnViewData);
        DB = new DatabaseHandler(this);

        showDialog(); //Permitira mostar LA INFORMACIÓN RECIBIDA DEL ListActivity

        //Evento Click de los botones
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String NOMBRETXT= NOMBRE_COMPLETO.getText().toString();
                String DIRECCIÓNTXT=DIRECCIÓN.getText().toString();
                String TELEFONOTXT=TELEFONO.getText().toString();

                Boolean checkInsert=DB.insertData(NOMBRETXT,DIRECCIÓNTXT,TELEFONOTXT);

                //Evaluar si la data ha sido insertada
                if(checkInsert==true){
                    Toast.makeText(MainActivity.this, "SE HA INSERTADO LA INFORMACIÓN",
                            Toast.LENGTH_LONG).show();
                }else{
                    Toast.makeText(MainActivity.this, "NO SE HA PODIDO INSERTAR LA INFORMACIÓN",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        //boton para mostrar los registros
        LISTA_DE_PRODUCTOS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor result= DB.getData();

                //evaluar si ya existen registros en la tabla
                if(result.getCount()==0){
                    Toast.makeText(MainActivity.this, "AUN NO HAY INFORMACIÓN",
                            Toast.LENGTH_LONG).show();
                    return;
                }
                StringBuffer buffer= new StringBuffer();
    }
            //leer el cursor y almacenar La Información en un StringBuffer
                while(result.moveToNext()){
                buffer.append("NOMBRE: " + DB.getString(0)+"\n");
                buffer.append("DIRECCIÓN: " + DB.getString(1)+"\n");
                buffer.append("TELEFONO: " + DB.getString(2)+"\n\n");
            }

            //MOSTRAR LA INFORMACIÓN
            AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("LISTADO DE PERSONAS QUE ENCARGARON");
                builder.setMessage(buffer.toString());
                builder.show();
        }
    }

    //BOTON ACTUALIZAR
        update.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String NOMBRE_COMPLETOTXT=NOMBRE_COMPLETO.getText().toString();
            String DIRECCIÓNTXT= DIRECCIÓN.getText().toString();
            String TELEFONOTXT=TELEFONO.getText().toString();

            Boolean checkInsert=DB.updateData(NOMBRE_COMPLETOTXT,DIRECCIÓNTXT,TELEFONOTXT);//llamado al metodo updateData de la clase DatabaseHandler


            //evaluar si la data ha sido actualizado
            if(checkInsert==true){
                Toast.makeText(MainActivity.this, "SE HA INSERTADO LA INFORMACIÓN",
                        Toast.LENGTH_LONG).show();
            }else{
                Toast.makeText(MainActivity.this, "NO SE HA PODIDO INSERTAR LA INFORMACIÓN",
                        Toast.LENGTH_LONG).show();


                private void showData() {
                    try{
                        Bundle bundle= getIntent().getExtras();
                        action = bundle.getString("action");
                        if(action.equals("edit")){

                            //mostar/ocultar botones
                            update.setVisibility(View.VISIBLE);
                            insert.setVisibility(View.GONE);


                            String PERSONA[]=bundle.getStringArray("PERSONA");
                            TextView tempVal = (TextView) findViewById(R.id.id);
                            tempVal.setText(idP);

                            tempVal=(TextView) findViewById(R.id.NOMBRE_COMPLETO);
                            tempVal.setText(person[0].toString());

                            tempVal=(TextView) findViewById(R.id.DIRECCIÓN);
                            tempVal.setText(person[1].toString());

                            tempVal=(TextView) findViewById(R.id.TELEFONO);
                            tempVal.setText(person[1].toString());


                        }
                    }catch (Exception e){
                        Toast.makeText(MainActivity.this, "Error: " +
                                e.getMessage().toString(), Toast.LENGTH_LONG).show();

                    }
                }
            }
