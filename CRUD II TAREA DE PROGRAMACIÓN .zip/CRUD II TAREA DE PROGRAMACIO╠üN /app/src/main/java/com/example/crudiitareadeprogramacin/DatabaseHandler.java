package com.example.crudiitareadeprogramacin;

import android.content.Context;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler {


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DatabaseHandler extends SQLiteOpenHelper {

    //CONSTRUCTOR
    public DatabaseHandler(Context context) {
        super(context, "PLANILLA.db", null, 1);
    }

     @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE PLANILLA( IDCRUDII TEXT PRIMARY KEY, NOMBRE_COMPLETO TEXT, DIRECCIÓN TEXT, TELEFONO TEXT)"); //crear la tabla de la base de datos
    }

     @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS PLANILLA");
    }

    //metodos CRUD

    //CREATE
    public Boolean insertData(String CRUDII, String NOMBRE, String DIRECCIÓN, String TELEFONO){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IDPLANILLA",CRUDII);
        contentValues.put("NOMBRE_COMPLETO", NOMBRE);
        contentValues.put("DIRECCIÓN",DIRECCIÓN);
        contentValues.put("TELEFONO",TELEFONO)
        long result= db.insert("PLANILLA", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    //OBTENER LOS DATOS
    //READ
    public Cursor getData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor=db.rawQuery("SELECT * FROM PLANILLA", null);
        return  cursor;
    }

    //UPDATE (actualizar los registros)
    public Boolean updateData(String CRUDII, String NOMBRE, String DIRECCIÓN, String TELEFONO){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("IDPLANILLA",CRUDII);
        contentValues.put("NOMBRE_COMPLETO", NOMBRE);
        contentValues.put("DIRECCIÓN",DIRECCIÓN);
        contentValues.put("TELEFONO",TELEFONO)

        //busqueda del registro a actualizar
        Cursor cursor = db.rawQuery("SELECT * FROM PERSONA WHERE =?", new String[]{CRUDII});

        //evaluar si el registro existe
        if(cursor.getCount()>0){
            long result = db).update("PLANILLA", contentValues, "IDPLANILLA=?", new String[]{CRUDII});
            if(result==-1){
                return false;
            }else{
                return  true;
            }
        }else{
            return false;
        }
    }

    //DELETE (eliminar registros)
    public Boolean deleteData(String id){
        SQLiteDatabase db = this.getWritableDatabase();

        //busqueda del registro a eliminar
        Cursor cursor = db.rawQuery("SELECT * FROM PLANILLA WHERE ?", new String[]{id});

        if(cursor.getCount()>0){
            long result=db.delete("IDPERSONA","NOMBRE_COMPLETO=?", new String[]{id});
            if(result==-1){
                return  false;
            }else{
                return true;
            }
        }else{
            return  false;
        }
    }

    

}